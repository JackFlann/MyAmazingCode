document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const analysisResults = document.getElementById('analysis-results');

    form.addEventListener('submit', async function(event) {
        event.preventDefault();
        
        const formData = new FormData(form);
        const symbol = formData.get('symbol');
        const analysisType = formData.get('analysis_type');

        // Make a POST request to the Flask server
        const response = await fetch('/', {
            method: 'POST',
            body: JSON.stringify({ symbol, analysisType }),
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();

        // Display the analysis results
        analysisResults.innerHTML = `
            <h3>Analysis Results for ${symbol}</h3>
            <p>${data.result}</p>
        `;

        // Show the analysis results section
        document.getElementById('analysis').classList.add('active');
    });
});
